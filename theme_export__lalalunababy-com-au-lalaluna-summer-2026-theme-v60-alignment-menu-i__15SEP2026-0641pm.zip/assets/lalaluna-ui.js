/* ==========================================================================
   LaLaLuna UI helpers
   - Reveal-on-scroll for .lala-reveal
   - Sticky header scrolled state
   - Mobile drawer open/close
   - Accessible desktop/menu drawer submenu cleanup
   ========================================================================== */

(function () {
  'use strict';

  // ----- Reveal on scroll -----
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) {
          e.target.classList.add('is-in');
          io.unobserve(e.target);
        }
      });
    }, { rootMargin: '0px 0px -10% 0px', threshold: 0.05 });

    var observe = function () {
      document.querySelectorAll('.lala-reveal:not(.is-in)').forEach(function (el) {
        io.observe(el);
      });
    };

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', observe);
    } else {
      observe();
    }

    // Re-observe when Shopify's section is re-rendered in the editor
    document.addEventListener('shopify:section:load', observe);
  } else {
    document.documentElement.classList.add('no-js');
  }

  // ----- Header scroll state -----
  var header = document.querySelector('[data-lala-header]');
  if (header) {
    var lastY = 0;
    var ticking = false;

    var onScroll = function () {
      var y = window.scrollY;
      header.classList.toggle('is-scrolled', y > 8);
      header.classList.toggle('is-hidden', y > 240 && y > lastY + 4);
      lastY = y;
      ticking = false;
    };

    window.addEventListener('scroll', function () {
      if (!ticking) {
        window.requestAnimationFrame(onScroll);
        ticking = true;
      }
    }, { passive: true });
    onScroll();
  }

  // ----- Mobile drawer -----
  var drawer = document.querySelector('[data-lala-drawer]');
  var drawerToggle = document.querySelectorAll('[data-lala-drawer-toggle]');
  var drawerClose = document.querySelectorAll('[data-lala-drawer-close]');

  var setDrawer = function (open) {
    if (!drawer) return;
    drawer.classList.toggle('is-open', open);
    document.documentElement.classList.toggle('lala-no-scroll', open);
    drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
    drawerToggle.forEach(function (b) { b.setAttribute('aria-expanded', open ? 'true' : 'false'); });
    if (!open) {
      drawer.querySelectorAll('details[open]').forEach(function (details) {
        details.removeAttribute('open');
      });
    }
    if (open) {
      var first = drawer.querySelector('a, button, summary');
      if (first) first.focus();
    }
  };

  drawerToggle.forEach(function (btn) {
    btn.addEventListener('click', function () {
      setDrawer(!drawer.classList.contains('is-open'));
    });
  });

  drawerClose.forEach(function (btn) {
    btn.addEventListener('click', function () { setDrawer(false); });
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && drawer && drawer.classList.contains('is-open')) {
      setDrawer(false);
    }
  });

  // ----- Header submenu details -----
  var headerMenuDetails = document.querySelectorAll('.lala-nav__details');

  var closeHeaderMenuDetails = function (except) {
    headerMenuDetails.forEach(function (details) {
      if (details !== except) details.removeAttribute('open');
    });
  };

  headerMenuDetails.forEach(function (details) {
    var summary = details.querySelector('summary');
    if (!summary) return;

    summary.addEventListener('click', function () {
      window.setTimeout(function () {
        if (details.hasAttribute('open')) closeHeaderMenuDetails(details);
      }, 0);
    });

    details.addEventListener('mouseenter', function () {
      if (!window.matchMedia('(min-width: 990px)').matches) return;
      closeHeaderMenuDetails(details);
      details.setAttribute('open', '');
    });

    details.addEventListener('mouseleave', function () {
      if (!window.matchMedia('(min-width: 990px)').matches) return;
      details.removeAttribute('open');
    });
  });

  document.addEventListener('click', function (e) {
    if (!e.target.closest('.lala-nav__details')) {
      closeHeaderMenuDetails();
    }
  });

})();