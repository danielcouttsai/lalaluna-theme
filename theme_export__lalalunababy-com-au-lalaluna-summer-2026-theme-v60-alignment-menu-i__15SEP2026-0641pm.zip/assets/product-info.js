if (!customElements.get('product-info')) {
  customElements.define(
    'product-info',
    class ProductInfo extends HTMLElement {
      quantityInput = undefined;
      quantityForm = undefined;
      onVariantChangeUnsubscriber = undefined;
      cartUpdateUnsubscriber = undefined;
      abortController = undefined;
      pendingRequestUrl = null;
      preProcessHtmlCallbacks = [];
      postProcessHtmlCallbacks = [];

      constructor() {
        super();

        this.quantityInput = this.querySelector('.quantity__input');
      }

      connectedCallback() {
        this.initializeProductSwapUtility();

        this.onVariantChangeUnsubscriber = subscribe(
          PUB_SUB_EVENTS.optionValueSelectionChange,
          this.handleOptionValueChange.bind(this)
        );

        this.initQuantityHandlers();
        this.syncDirectVariantProductFormState();
        this.dispatchEvent(new CustomEvent('product-info:loaded', { bubbles: true }));
      }

      addPreProcessCallback(callback) {
        this.preProcessHtmlCallbacks.push(callback);
      }

      initQuantityHandlers() {
        if (!this.quantityInput) return;

        this.quantityForm = this.querySelector('.product-form__quantity');
        if (!this.quantityForm) return;

        this.setQuantityBoundries();
        if (!this.dataset.originalSection) {
          this.cartUpdateUnsubscriber = subscribe(PUB_SUB_EVENTS.cartUpdate, this.fetchQuantityRules.bind(this));
        }
      }

      disconnectedCallback() {
        this.onVariantChangeUnsubscriber();
        this.cartUpdateUnsubscriber?.();
      }

      initializeProductSwapUtility() {
        this.preProcessHtmlCallbacks.push((html) =>
          html.querySelectorAll('.scroll-trigger').forEach((element) => element.classList.add('scroll-trigger--cancel'))
        );
        this.postProcessHtmlCallbacks.push((newNode) => {
          window?.Shopify?.PaymentButton?.init();
          window?.ProductModel?.loadShopifyXR();
        });
      }

      handleOptionValueChange({ data: { event, target, selectedOptionValues } }) {
        if (!this.contains(event.target)) return;

        this.resetProductFormState();

        const productUrl = target.dataset.productUrl || this.pendingRequestUrl || this.dataset.url;
        this.pendingRequestUrl = productUrl;
        const shouldSwapProduct = this.dataset.url !== productUrl;
        const shouldFetchFullPage = this.dataset.updateUrl === 'true' && shouldSwapProduct;

        if (this.isDirectVariantProduct && !shouldSwapProduct) {
          this.handleDirectVariantOptionValueChange(productUrl);
          document.querySelector(`#${target.id}`)?.focus();
          return;
        }

        this.renderProductInfo({
          requestUrl: this.buildRequestUrlWithParams(productUrl, selectedOptionValues, shouldFetchFullPage),
          targetId: target.id,
          callback: shouldSwapProduct
            ? this.handleSwapProduct(productUrl, shouldFetchFullPage)
            : this.handleUpdateProductInfo(productUrl),
        });
      }

      resetProductFormState() {
        const productForm = this.productForm;
        productForm?.toggleSubmitButton(true);
        productForm?.handleErrorMessage();
      }

      handleSwapProduct(productUrl, updateFullPage) {
        return (html) => {
          this.productModal?.remove();

          const selector = updateFullPage ? "product-info[id^='MainProduct']" : 'product-info';
          const variant = this.getSelectedVariant(html.querySelector(selector));
          this.updateURL(productUrl, variant?.id);

          if (updateFullPage) {
            document.querySelector('head title').innerHTML = html.querySelector('head title').innerHTML;

            HTMLUpdateUtility.viewTransition(
              document.querySelector('main'),
              html.querySelector('main'),
              this.preProcessHtmlCallbacks,
              this.postProcessHtmlCallbacks
            );
          } else {
            HTMLUpdateUtility.viewTransition(
              this,
              html.querySelector('product-info'),
              this.preProcessHtmlCallbacks,
              this.postProcessHtmlCallbacks
            );
          }
        };
      }

      renderProductInfo({ requestUrl, targetId, callback }) {
        this.abortController?.abort();
        this.abortController = new AbortController();

        fetch(requestUrl, { signal: this.abortController.signal })
          .then((response) => response.text())
          .then((responseText) => {
            this.pendingRequestUrl = null;
            const html = new DOMParser().parseFromString(responseText, 'text/html');
            callback(html);
          })
          .then(() => {
            // set focus to last clicked option value
            document.querySelector(`#${targetId}`)?.focus();
          })
          .catch((error) => {
            if (error.name === 'AbortError') {
              console.log('Fetch aborted by user');
            } else {
              console.error(error);
            }
          });
      }

      getSelectedVariant(productInfoNode) {
        const selectedVariant = productInfoNode.querySelector('variant-selects [data-selected-variant]')?.innerHTML;
        return !!selectedVariant ? JSON.parse(selectedVariant) : null;
      }

      buildRequestUrlWithParams(url, optionValues, shouldFetchFullPage = false) {
        const params = [];

        !shouldFetchFullPage && params.push(`section_id=${this.sectionId}`);

        if (optionValues.length) {
          params.push(`option_values=${optionValues.join(',')}`);
        }

        return `${url}?${params.join('&')}`;
      }

      updateOptionValues(html) {
        const variantSelects = html.querySelector('variant-selects');
        if (variantSelects) {
          HTMLUpdateUtility.viewTransition(this.variantSelectors, variantSelects, this.preProcessHtmlCallbacks);
        }
      }

      handleUpdateProductInfo(productUrl) {
        return (html) => {
          const directFallbackVariant = this.getDirectSelectedVariant();
          const variant = this.getSelectedVariant(html) || (this.isDirectVariantProduct ? directFallbackVariant : null);

          this.pickupAvailability?.update(variant);
          this.updateOptionValues(html);
          this.updateURL(productUrl, variant?.id);
          this.updateVariantInputs(variant?.id);

          if (!variant) {
            this.setUnavailable();
            return;
          }

          this.updateMedia(html, variant?.featured_media?.id);

          const updateSourceFromDestination = (id, shouldHide = (source) => false) => {
            const source = html.getElementById(`${id}-${this.sectionId}`);
            const destination = this.querySelector(`#${id}-${this.dataset.section}`);
            if (source && destination) {
              destination.innerHTML = source.innerHTML;
              destination.classList.toggle('hidden', shouldHide(source));
            }
          };

          updateSourceFromDestination('price');
          updateSourceFromDestination('Sku', ({ classList }) => classList.contains('hidden'));
          updateSourceFromDestination('Inventory', ({ innerText }) => innerText === '');
          updateSourceFromDestination('Volume');
          updateSourceFromDestination('Price-Per-Item', ({ classList }) => classList.contains('hidden'));

          this.updateQuantityRules(this.sectionId, html);
          this.querySelector(`#Quantity-Rules-${this.dataset.section}`)?.classList.remove('hidden');
          this.querySelector(`#Volume-Note-${this.dataset.section}`)?.classList.remove('hidden');

          const shouldDisableSubmit = this.isDirectVariantProduct
            ? !variant.available
            : html.getElementById(`ProductSubmitButton-${this.sectionId}`)?.hasAttribute('disabled') ?? true;

          this.productForm?.toggleSubmitButton(
            shouldDisableSubmit,
            shouldDisableSubmit ? window.variantStrings.soldOut : undefined
          );

          if (this.isDirectVariantProduct) this.syncDirectVariantProductFormState(variant);

          publish(PUB_SUB_EVENTS.variantChange, {
            data: {
              sectionId: this.sectionId,
              html,
              variant,
            },
          });
        };
      }

      updateVariantInputs(variantId, isAvailable = Boolean(variantId)) {
        this.querySelectorAll(
          `#product-form-${this.dataset.section}, #product-form-installment-${this.dataset.section}`
        ).forEach((productForm) => {
          const input = productForm.querySelector('input[name="id"]');
          input.value = variantId ?? '';
          input.disabled = !variantId || !isAvailable;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        });
      }

      syncDirectVariantProductFormState(variant = this.getDirectSelectedVariant()) {
        if (!this.isDirectVariantProduct || !variant) return false;

        this.updateVariantInputs(variant.id, variant.available);
        this.productForm?.toggleSubmitButton(!variant.available, variant.available ? undefined : window.variantStrings.soldOut);
        return true;
      }

      handleDirectVariantOptionValueChange(productUrl) {
        const variant = this.getDirectSelectedVariant();

        if (!variant) {
          this.updateURL(productUrl);
          this.updateVariantInputs();
          this.setUnavailable();
          return;
        }

        this.pendingRequestUrl = null;
        this.pickupAvailability?.update(variant);
        this.updateURL(productUrl, variant.id);
        this.updateVariantInputs(variant.id, variant.available);
        this.productForm?.toggleSubmitButton(!variant.available, variant.available ? undefined : window.variantStrings.soldOut);
        this.updateDirectSelectedVariantScript(variant);

        publish(PUB_SUB_EVENTS.variantChange, {
          data: {
            sectionId: this.sectionId,
            html: null,
            variant,
          },
        });
      }

      updateDirectSelectedVariantScript(variant) {
        const selectedVariantScript = this.variantSelectors?.querySelector('[data-selected-variant]');
        if (!selectedVariantScript || !variant) return;
        selectedVariantScript.textContent = JSON.stringify(variant);
      }

      getDirectSelectedVariant() {
        if (!this.isDirectVariantProduct) return null;

        const variants = this.directVariants;
        const selectedOptions = this.selectedDirectOptions;
        if (!variants.length || !selectedOptions.length) return null;

        const normaliseOption = (value) => `${value ?? ''}`.trim().replace(/\s+/g, ' ');
        const exactMatch = variants.find((variant) => {
          const options = variant.options || [variant.option1, variant.option2, variant.option3].filter(Boolean);
          return options.length === selectedOptions.length && options.every((option, index) => option === selectedOptions[index]);
        });

        if (exactMatch) return exactMatch;

        return (
          variants.find((variant) => {
            const options = variant.options || [variant.option1, variant.option2, variant.option3].filter(Boolean);
            return (
              options.length === selectedOptions.length &&
              options.every((option, index) => normaliseOption(option) === normaliseOption(selectedOptions[index]))
            );
          }) || null
        );
      }

      get selectedDirectOptions() {
        if (!this.variantSelectors) return [];

        return Array.from(this.variantSelectors.querySelectorAll('select, fieldset input:checked'))
          .map((input) => (input.tagName === 'SELECT' ? input.value : input.value))
          .filter(Boolean);
      }

      get directVariants() {
        const variantsJson = this.variantSelectors?.querySelector('[data-lala-direct-variants]')?.textContent;
        if (!variantsJson) return [];

        try {
          return JSON.parse(variantsJson);
        } catch (error) {
          console.error(error);
          return [];
        }
      }

      get isDirectVariantProduct() {
        return this.variantSelectors?.dataset.lalaDirectVariantReconcile === 'true' || this.variantSelectors?.dataset.lalaWaterShoes === 'true' || this.variantSelectors?.dataset.lalaGiftVoucher === 'true';
      }

      get isWaterShoesProduct() {
        return this.variantSelectors?.dataset.lalaWaterShoes === 'true';
      }

      updateURL(url, variantId) {
        this.querySelector('share-button')?.updateUrl(
          `${window.shopUrl}${url}${variantId ? `?variant=${variantId}` : ''}`
        );

        if (this.dataset.updateUrl === 'false') return;
        window.history.replaceState({}, '', `${url}${variantId ? `?variant=${variantId}` : ''}`);
      }

      setUnavailable() {
        this.productForm?.toggleSubmitButton(true, window.variantStrings.unavailable);

        const selectors = ['price', 'Inventory', 'Sku', 'Price-Per-Item', 'Volume-Note', 'Volume', 'Quantity-Rules']
          .map((id) => `#${id}-${this.dataset.section}`)
          .join(', ');
        document.querySelectorAll(selectors).forEach(({ classList }) => classList.add('hidden'));
      }

      updateMedia(html, variantFeaturedMediaId) {
        if (!variantFeaturedMediaId) return;

        const mediaGallerySource = this.querySelector('media-gallery ul');
        const mediaGalleryDestination = html.querySelector(`media-gallery ul`);

        const refreshSourceData = () => {
          if (this.hasAttribute('data-zoom-on-hover')) enableZoomOnHover(2);
          const mediaGallerySourceItems = Array.from(mediaGallerySource.querySelectorAll('li[data-media-id]'));
          const sourceSet = new Set(mediaGallerySourceItems.map((item) => item.dataset.mediaId));
          const sourceMap = new Map(
            mediaGallerySourceItems.map((item, index) => [item.dataset.mediaId, { item, index }])
          );
          return [mediaGallerySourceItems, sourceSet, sourceMap];
        };

        if (mediaGallerySource && mediaGalleryDestination) {
          let [mediaGallerySourceItems, sourceSet, sourceMap] = refreshSourceData();
          const mediaGalleryDestinationItems = Array.from(
            mediaGalleryDestination.querySelectorAll('li[data-media-id]')
          );
          const destinationSet = new Set(mediaGalleryDestinationItems.map(({ dataset }) => dataset.mediaId));
          let shouldRefresh = false;

          // add items from new data not present in DOM
          for (let i = mediaGalleryDestinationItems.length - 1; i >= 0; i--) {
            if (!sourceSet.has(mediaGalleryDestinationItems[i].dataset.mediaId)) {
              mediaGallerySource.prepend(mediaGalleryDestinationItems[i]);
              shouldRefresh = true;
            }
          }

          // remove items from DOM not present in new data
          for (let i = 0; i < mediaGallerySourceItems.length; i++) {
            if (!destinationSet.has(mediaGallerySourceItems[i].dataset.mediaId)) {
              mediaGallerySourceItems[i].remove();
              shouldRefresh = true;
            }
          }

          // refresh
          if (shouldRefresh) [mediaGallerySourceItems, sourceSet, sourceMap] = refreshSourceData();

          // if media galleries don't match, sort to match new data order
          mediaGalleryDestinationItems.forEach((destinationItem, destinationIndex) => {
            const sourceData = sourceMap.get(destinationItem.dataset.mediaId);

            if (sourceData && sourceData.index !== destinationIndex) {
              mediaGallerySource.insertBefore(
                sourceData.item,
                mediaGallerySource.querySelector(`li:nth-of-type(${destinationIndex + 1})`)
              );

              // refresh source now that it has been modified
              [mediaGallerySourceItems, sourceSet, sourceMap] = refreshSourceData();
            }
          });
        }

        // set featured media as active in the media gallery
        this.querySelector(`media-gallery`)?.setActiveMedia?.(
          `${this.dataset.section}-${variantFeaturedMediaId}`,
          true
        );

        // update media modal
        const modalContent = this.productModal?.querySelector(`.product-media-modal__content`);
        const newModalContent = html.querySelector(`product-modal .product-media-modal__content`);
        if (modalContent && newModalContent) modalContent.innerHTML = newModalContent.innerHTML;
      }

      setQuantityBoundries() {
        const data = {
          cartQuantity: this.quantityInput.dataset.cartQuantity ? parseInt(this.quantityInput.dataset.cartQuantity) : 0,
          min: this.quantityInput.dataset.min ? parseInt(this.quantityInput.dataset.min) : 1,
          max: this.quantityInput.dataset.max ? parseInt(this.quantityInput.dataset.max) : null,
          step: this.quantityInput.step ? parseInt(this.quantityInput.step) : 1,
        };

        let min = data.min;
        const max = data.max === null ? data.max : data.max - data.cartQuantity;
        if (max !== null) min = Math.min(min, max);
        if (data.cartQuantity >= data.min) min = Math.min(min, data.step);

        this.quantityInput.min = min;

        if (max) {
          this.quantityInput.max = max;
        } else {
          this.quantityInput.removeAttribute('max');
        }
        this.quantityInput.value = min;

        publish(PUB_SUB_EVENTS.quantityUpdate, undefined);
      }

      fetchQuantityRules() {
        const currentVariantId = this.productForm?.variantIdInput?.value;
        if (!currentVariantId) return;

        this.querySelector('.quantity__rules-cart .loading__spinner').classList.remove('hidden');
        fetch(`${this.dataset.url}?variant=${currentVariantId}&section_id=${this.dataset.section}`)
          .then((response) => response.text())
          .then((responseText) => {
            const html = new DOMParser().parseFromString(responseText, 'text/html');
            this.updateQuantityRules(this.dataset.section, html);
          })
          .catch((e) => console.error(e))
          .finally(() => this.querySelector('.quantity__rules-cart .loading__spinner').classList.add('hidden'));
      }

      updateQuantityRules(sectionId, html) {
        if (!this.quantityInput) return;
        this.setQuantityBoundries();

        const quantityFormUpdated = html.getElementById(`Quantity-Form-${sectionId}`);
        const selectors = ['.quantity__input', '.quantity__rules', '.quantity__label'];
        for (let selector of selectors) {
          const current = this.quantityForm.querySelector(selector);
          const updated = quantityFormUpdated.querySelector(selector);
          if (!current || !updated) continue;
          if (selector === '.quantity__input') {
            const attributes = ['data-cart-quantity', 'data-min', 'data-max', 'step'];
            for (let attribute of attributes) {
              const valueUpdated = updated.getAttribute(attribute);
              if (valueUpdated !== null) {
                current.setAttribute(attribute, valueUpdated);
              } else {
                current.removeAttribute(attribute);
              }
            }
          } else {
            current.innerHTML = updated.innerHTML;
          }
        }
      }

      get productForm() {
        return this.querySelector(`product-form`);
      }

      get productModal() {
        return document.querySelector(`#ProductModal-${this.dataset.section}`);
      }

      get pickupAvailability() {
        return this.querySelector(`pickup-availability`);
      }

      get variantSelectors() {
        return this.querySelector('variant-selects');
      }

      get relatedProducts() {
        const relatedProductsSectionId = SectionId.getIdForSection(
          SectionId.parseId(this.sectionId),
          'related-products'
        );
        return document.querySelector(`product-recommendations[data-section-id^="${relatedProductsSectionId}"]`);
      }

      get quickOrderList() {
        const quickOrderListSectionId = SectionId.getIdForSection(
          SectionId.parseId(this.sectionId),
          'quick_order_list'
        );
        return document.querySelector(`quick-order-list[data-id^="${quickOrderListSectionId}"]`);
      }

      get sectionId() {
        return this.dataset.originalSection || this.dataset.section;
      }
    }
  );
}

/* La La Luna global variant reconciliation
   Root-cause guard for products where Dawn's section refresh can leave the wrong
   variant id or a stale disabled Add to Cart state after option changes.
   This is deliberately product-type agnostic: it compares selected option values
   against variant.options and updates only the active product form. */
(() => {
  if (window.__lalaGlobalVariantReconcilerLoaded) return;
  window.__lalaGlobalVariantReconcilerLoaded = true;

  const normalise = (value) => String(value == null ? '' : value).replace(/\s+/g, ' ').trim();

  const readVariants = (picker) => {
    const node = picker?.querySelector('[data-lala-direct-variants]');
    if (!node?.textContent) return [];
    try {
      const parsed = JSON.parse(node.textContent);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error('[LaLaLuna] Could not parse product variants', error);
      return [];
    }
  };

  const selectedOptions = (picker) => {
    if (!picker) return [];
    return Array.from(picker.querySelectorAll('select, fieldset input:checked'))
      .map((input) => (input.tagName === 'SELECT' ? input.value : input.value))
      .filter(Boolean)
      .map(normalise);
  };

  const variantOptions = (variant) => {
    if (Array.isArray(variant?.options) && variant.options.length) return variant.options.map(normalise);
    return [variant?.option1, variant?.option2, variant?.option3].filter(Boolean).map(normalise);
  };

  const findVariant = (picker) => {
    const variants = readVariants(picker);
    const selected = selectedOptions(picker);
    if (!variants.length || !selected.length) return null;

    return (
      variants.find((variant) => {
        const options = variantOptions(variant);
        return options.length === selected.length && options.every((option, index) => option === selected[index]);
      }) || null
    );
  };

  const getSectionId = (picker) => picker?.dataset?.section || picker?.closest('product-info')?.dataset?.section || '';

  const syncVariant = (picker) => {
    if (!picker || !picker.matches('variant-selects')) return;

    const sectionId = getSectionId(picker);
    const productInfo = picker.closest('product-info') || document;
    const variant = findVariant(picker);
    const available = Boolean(variant && variant.available);

    const forms = new Set();
    if (sectionId && window.CSS?.escape) {
      productInfo.querySelectorAll(`#product-form-${CSS.escape(sectionId)}, #product-form-installment-${CSS.escape(sectionId)}`).forEach((form) => forms.add(form));
    }
    productInfo.querySelectorAll('product-form form, form[data-type="add-to-cart-form"]').forEach((form) => forms.add(form));

    forms.forEach((form) => {
      const input = form.querySelector('input[name="id"]');
      if (!input) return;
      input.value = variant ? variant.id : '';
      input.disabled = !available;
      input.dispatchEvent(new Event('change', { bubbles: true }));
    });

    const buttons = new Set();
    if (sectionId && window.CSS?.escape) {
      productInfo.querySelectorAll(`#ProductSubmitButton-${CSS.escape(sectionId)}, #product-form-${CSS.escape(sectionId)} [name="add"]`).forEach((button) => buttons.add(button));
    }
    productInfo.querySelectorAll('product-form [name="add"], button.product-form__submit').forEach((button) => buttons.add(button));

    const label = available
      ? window.variantStrings?.addToCart || 'Add to cart'
      : variant
        ? window.variantStrings?.soldOut || 'Sold out'
        : window.variantStrings?.unavailable || 'Unavailable';

    buttons.forEach((button) => {
      const text = button.querySelector('span:not(.sold-out-message)') || button.querySelector('span');
      const soldOutMessage = button.querySelector('.sold-out-message');

      if (available) {
        button.removeAttribute('disabled');
        button.removeAttribute('aria-disabled');
        button.classList.remove('disabled');
        if (text) {
          text.classList.remove('hidden');
          text.textContent = label;
        }
        soldOutMessage?.classList.add('hidden');
      } else {
        button.setAttribute('disabled', 'disabled');
        button.setAttribute('aria-disabled', 'true');
        if (text) text.textContent = label;
      }
    });

    const selectedVariantScript = picker.querySelector('[data-selected-variant]');
    if (selectedVariantScript && variant) selectedVariantScript.textContent = JSON.stringify(variant);

    const url = productInfo.dataset?.url || picker.dataset?.productUrl;
    if (variant && productInfo.dataset?.updateUrl !== 'false' && url && window.history?.replaceState) {
      const next = `${url}?variant=${variant.id}`;
      if (window.location.pathname === url && window.location.search !== `?variant=${variant.id}`) {
        window.history.replaceState({}, '', next);
      }
    }

    if (variant && window.publish && window.PUB_SUB_EVENTS?.variantChange) {
      window.publish(window.PUB_SUB_EVENTS.variantChange, {
        data: {
          sectionId: sectionId,
          html: null,
          variant: variant,
        },
      });
    }
  };

  const scheduleSync = (picker) => {
    if (!picker) return;
    syncVariant(picker);
    window.setTimeout(() => syncVariant(picker), 0);
    window.setTimeout(() => syncVariant(picker), 120);
    window.setTimeout(() => syncVariant(picker), 320);
  };

  document.addEventListener(
    'change',
    (event) => {
      const picker = event.target?.closest?.('variant-selects');
      if (!picker) return;
      scheduleSync(picker);
    },
    true
  );

  document.addEventListener('product-info:loaded', (event) => {
    event.target?.querySelectorAll?.('variant-selects').forEach(scheduleSync);
  });

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('variant-selects').forEach(scheduleSync);
  });
})();
