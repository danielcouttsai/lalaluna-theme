/* La La Luna — ll-summer.js
 * Namespaced analytics events fired via window.dispatchEvent(new CustomEvent(...)):
 *   ll_product_add_to_cart   { product_id, variant_id, title, price, source }
 *   ll_summer_kit_add        { items: [{variant_id, title, price}], total }
 *   ll_summer_kit_step       { step_index, step_title, variant_id, title }
 *   ll_fit_finder_complete   { step1, step2, step3, result_name, result_handle }
 *   ll_search_submitted      { terms, result_count }
 *   ll_cta_click             { label, href, section }
 *   ll_pdp_sticky_add        { product_id, variant_id, title, price }
 * All events are non-blocking; analytics errors never interrupt commerce.
 */
/* Progressive enhancement only. Shopify owns prices, variants, cart and checkout. */
(() => {
  'use strict';
  const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  // Keep Shopify's native pixel events intact; add a namespaced hook only when
  // a merchant dataLayer or Shopify Web Pixels runtime is already present.
  const publish = (name, data = {}) => {
    try { window.Shopify?.analytics?.publish?.(name, data); } catch (error) { /* analytics must never block commerce */ }
    if (Array.isArray(window.dataLayer)) window.dataLayer.push({event: name, ...data});
  };
  function initAnalytics(root = document) {
    root.querySelectorAll('form[data-type="add-to-cart-form"]:not([data-ll-analytics])').forEach(form => {
      form.dataset.llAnalytics = 'true';
      form.addEventListener('submit', () => {
        const variant = form.querySelector('[name="id"]')?.value;
        const quantity = form.querySelector('[name="quantity"]')?.value || 1;
        publish('ll_product_add_to_cart', {variant_id: variant || null, quantity: Number(quantity) || 1, source: 'product_card'});
      });
    });
    root.querySelectorAll('form[role="search"]:not([data-ll-analytics])').forEach(form => {
      form.dataset.llAnalytics = 'true';
      form.addEventListener('submit', () => {
        const terms = form.querySelector('input[name="q"]')?.value?.trim();
        if (terms) publish('ll_search_submitted', {search_term: terms});
      });
    });
    root.querySelectorAll('[data-kit-choose]:not([data-ll-analytics])').forEach(button => {
      button.dataset.llAnalytics = 'true';
      button.addEventListener('click', () => publish('ll_summer_kit_step_selected', {
        product_title: button.closest('[data-kit-product]')?.dataset.productTitle || null,
        step: button.closest('[data-kit-step]')?.dataset.kitStepTitle || null
      }));
    });
    root.querySelectorAll('[data-ll-cta]:not([data-ll-analytics])').forEach(link => {
      link.dataset.llAnalytics = 'true';
      link.addEventListener('click', () => publish('ll_cta_click', {
        cta: link.dataset.llCta || null,
        href: link.getAttribute('href') || null,
        experiment: link.closest('[data-ll-experiment]')?.dataset.llExperiment || null
      }));
    });
    root.querySelectorAll('[data-ll-experiment]:not([data-ll-experiment-tracked])').forEach(experiment => {
      const key = experiment.dataset.llExperiment;
      if (!key) return;
      experiment.dataset.llExperimentTracked = 'true';
      publish('ll_experiment_exposure', {experiment: key, page: window.location.pathname});
    });
    root.querySelectorAll('[data-lala-sticky-trigger]:not([data-ll-analytics])').forEach(button => {
      button.dataset.llAnalytics = 'true';
      button.addEventListener('click', () => publish('ll_pdp_sticky_add_to_cart', {source: 'sticky_pdp'}));
    });
  }
  function init(root = document) {
    root.querySelectorAll('[data-ll-carousel]:not([data-ll-ready])').forEach(row => {
      row.dataset.llReady = 'true';
      const track = row.querySelector('[data-ll-track]');
      const previous = row.querySelector('[data-ll-prev]');
      const next = row.querySelector('[data-ll-next]');
      if (!track || !previous || !next) return;
      const update = () => {
        previous.disabled = track.scrollLeft <= 2;
        next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 2;
        row.querySelector('.ll-track-controls').hidden = track.scrollWidth <= track.clientWidth + 2;
      };
      const move = direction => track.scrollBy({left: direction * (track.firstElementChild?.getBoundingClientRect().width + parseFloat(getComputedStyle(track).columnGap) || track.clientWidth), behavior: reduced() ? 'auto' : 'smooth'});
      previous.addEventListener('click', () => move(-1));
      next.addEventListener('click', () => move(1));
      track.addEventListener('scroll', update, {passive: true});
      if ('ResizeObserver' in window) new ResizeObserver(update).observe(track);
      else window.addEventListener('resize', update, {passive: true});
      update();
    });
    root.querySelectorAll('[data-ll-ribbon]:not([data-ll-ready])').forEach(ribbon => {
      ribbon.dataset.llReady = 'true';
    });
    root.querySelectorAll('[data-ll-menu]:not([data-ll-ready])').forEach(menu => {
      menu.dataset.llReady = 'true';
      const summary = menu.querySelector(':scope > summary');
      const panel = menu.querySelector('.ll-mobile-menu__panel');
      const close = () => {menu.open = false; summary.focus();};
      menu.querySelector('[data-ll-menu-close]')?.addEventListener('click', close);
      menu.addEventListener('toggle', () => {
        summary.setAttribute('aria-expanded', String(menu.open));
        document.documentElement.classList.toggle('ll-menu-open', menu.open);
        if (menu.open) panel.querySelector('button')?.focus();
      });
      menu.addEventListener('click', event => {if (event.target === menu) close();});
      menu.addEventListener('keydown', event => {
        if (!menu.open) return;
        if (event.key === 'Escape') {event.preventDefault();close();return;}
        if (event.key !== 'Tab') return;
        const focusable = [...panel.querySelectorAll('a[href],button,summary,input,select,[tabindex="0"]')].filter(el => el.getClientRects().length && !el.disabled);
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (event.shiftKey && document.activeElement === first) {event.preventDefault();last?.focus();}
        else if (!event.shiftKey && document.activeElement === last) {event.preventDefault();first?.focus();}
      });
    });
  }
  document.addEventListener('click', event => {
    document.querySelectorAll('.ll-desktop-nav details[open]').forEach(details => {if (!details.contains(event.target)) details.open = false;});
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') document.querySelectorAll('.ll-desktop-nav details[open]').forEach(details => {details.open = false;details.querySelector('summary')?.focus();});
  });
  // Rotating announcement bar: 5 s per message, pauses on hover or keyboard focus, off for reduced motion.
  function initAnnouncements(root = document) {
    root.querySelectorAll('[data-ll-announce]:not([data-ll-announce-ready])').forEach(bar => {
      bar.dataset.llAnnounceReady = 'true';
      const msgs = [...bar.querySelectorAll('[data-ll-announce-msg]')];
      if (msgs.length < 2 || reduced()) return;
      let index = 0, paused = false;
      const show = next => {
        msgs.forEach((msg, i) => {
          const on = i === next;
          msg.classList.toggle('is-active', on);
          if (on) msg.removeAttribute('aria-hidden'); else msg.setAttribute('aria-hidden', 'true');
          msg.querySelectorAll('a').forEach(a => { if (on) a.removeAttribute('tabindex'); else a.setAttribute('tabindex', '-1'); });
        });
        index = next;
      };
      ['mouseenter', 'focusin'].forEach(e => bar.addEventListener(e, () => { paused = true; }));
      ['mouseleave', 'focusout'].forEach(e => bar.addEventListener(e, () => { paused = false; }));
      setInterval(() => { if (!paused && !document.hidden) show((index + 1) % msgs.length); }, 5000);
    });
  }
  // Header search panel: focus the field on open; close on Escape, outside click or the close button.
  function initSearch(root = document) {
    root.querySelectorAll('[data-ll-search]:not([data-ll-search-ready])').forEach(panel => {
      panel.dataset.llSearchReady = 'true';
      const input = panel.querySelector('input[type="search"]');
      const trigger = panel.querySelector(':scope > summary');
      const close = (restoreFocus = true) => { panel.open = false; trigger?.setAttribute('aria-expanded', 'false'); if (restoreFocus) trigger?.focus(); };
      panel.addEventListener('toggle', () => {
        trigger?.setAttribute('aria-expanded', String(panel.open));
        if (panel.open) {
          document.querySelectorAll('[data-ll-menu][open]').forEach(menu => { menu.open = false; });
          setTimeout(() => input?.focus(), 30);
        }
      });
      panel.querySelector('[data-ll-search-close]')?.addEventListener('click', close);
      document.addEventListener('keydown', event => { if (event.key === 'Escape' && panel.open) close(); });
      document.addEventListener('click', event => { if (panel.open && !panel.contains(event.target)) close(false); });
    });
  }
  document.addEventListener('shopify:section:load', event => { init(event.target); initAnnouncements(event.target); initSearch(event.target); initDrawer(event.target); initKit(event.target); initAnalytics(event.target); });
  document.addEventListener('shopify:section:unload', () => document.documentElement.classList.remove('ll-menu-open', 'll-drawer-open'));
  function initPopup() {
    document.querySelectorAll('[data-ll-popup]:not([data-ll-popup-ready])').forEach(popup => {
      popup.dataset.llPopupReady = 'true';
      const cookie = popup.dataset.llPopupCookie;
      if (cookie && document.cookie.split(';').some(c => c.trim().startsWith(cookie + '='))) return;
      if (reduced()) return;
      const delay = parseInt(popup.dataset.llPopupDelay || '5') * 1000;
      const show = () => {
        popup.removeAttribute('hidden');
        const first = popup.querySelector('input:not([type="hidden"]), button:not([data-ll-popup-close]), a[href], [tabindex]:not([tabindex="-1"])');
        first?.focus();
      };
      const hide = () => {
        popup.setAttribute('hidden', '');
        if (cookie) { const d = new Date(); d.setDate(d.getDate() + 30); document.cookie = cookie + '=1;path=/;expires=' + d.toUTCString() + ';samesite=lax'; }
      };
      setTimeout(show, delay);
      popup.querySelectorAll('[data-ll-popup-close]').forEach(el => el.addEventListener('click', hide));
      document.addEventListener('keydown', e => { if (e.key === 'Escape' && !popup.hidden) { hide(); e.preventDefault(); } });
      popup.querySelector('.ll-popup__form')?.addEventListener('submit', () => setTimeout(hide, 2500));
    });
  }
  function initDrawer(root = document) {
    root.querySelectorAll('[data-ll-drawer]:not([data-ll-drawer-ready])').forEach(drawer => {
      drawer.dataset.llDrawerReady = 'true';
      const trigger = document.querySelector(`[data-ll-drawer-open][aria-controls="${drawer.id}"]`) || document.querySelector('[data-ll-drawer-open]');
      const closeButtons = [...drawer.querySelectorAll('[data-ll-drawer-close]')];
      const submenuButtons = [...drawer.querySelectorAll('[data-ll-submenu]')];
      const panels = [...drawer.querySelectorAll('[data-ll-submenu-panel]')];
      let previousFocus = null;
      const focusables = () => [...drawer.querySelectorAll('a[href],button,input,select,textarea,[tabindex]:not([tabindex="-1"])')]
        .filter(el => !el.disabled && !el.hidden && el.getClientRects().length);
      const resetSubmenus = () => {
        panels.forEach(panel => { panel.hidden = true; panel.classList.remove('is-active'); });
        submenuButtons.forEach(button => button.setAttribute('aria-expanded', 'false'));
      };
      const setSubmenu = name => {
        panels.forEach(panel => {
          const active = panel.id === `ll-submenu-${name}`;
          panel.hidden = !active;
          panel.classList.toggle('is-active', active);
        });
        submenuButtons.forEach(button => button.setAttribute('aria-expanded', String(button.dataset.llSubmenu === name)));
        panels.find(panel => panel.id === `ll-submenu-${name}`)?.querySelector('button, a[href]')?.focus();
      };
      const close = () => {
        drawer.classList.remove('is-open');
        drawer.setAttribute('aria-hidden', 'true');
        trigger?.setAttribute('aria-expanded', 'false');
        document.documentElement.classList.remove('ll-drawer-open');
        resetSubmenus();
        if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus();
        previousFocus = null;
      };
      const open = () => {
        document.querySelectorAll('[data-ll-drawer].is-open').forEach(other => { if (other !== drawer) other.classList.remove('is-open'); });
        previousFocus = document.activeElement;
        drawer.classList.add('is-open');
        drawer.setAttribute('aria-hidden', 'false');
        trigger?.setAttribute('aria-expanded', 'true');
        document.documentElement.classList.add('ll-drawer-open');
        resetSubmenus();
        requestAnimationFrame(() => drawer.querySelector('.ll-drawer__close')?.focus());
      };
      trigger?.addEventListener('click', () => drawer.classList.contains('is-open') ? close() : open());
      closeButtons.forEach(button => button.addEventListener('click', close));
      submenuButtons.forEach(button => button.addEventListener('click', () => setSubmenu(button.dataset.llSubmenu)));
      drawer.querySelectorAll('[data-ll-submenu-back]').forEach(button => button.addEventListener('click', () => {
        resetSubmenus();
        drawer.querySelector('.ll-menu__row, .ll-drawer__close')?.focus();
      }));
      drawer.addEventListener('keydown', event => {
        if (!drawer.classList.contains('is-open')) return;
        if (event.key === 'Escape') { event.preventDefault(); close(); return; }
        if (event.key !== 'Tab') return;
        const items = focusables();
        if (!items.length) return;
        const first = items[0], last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
      });
      drawer.setAttribute('aria-hidden', 'true');
      resetSubmenus();
    });
  }
  function initKit(root = document) {
    root.querySelectorAll('[data-ll-kit]:not([data-ll-kit-ready])').forEach(builder => {
      builder.dataset.llKitReady = 'true';
      const steps = [...builder.querySelectorAll('[data-kit-step]')];
      const requiredSteps = steps.filter(step => step.dataset.kitRequired === 'true');
      const requiredCount = requiredSteps.length;
      const state = new Map();
      const counter = builder.querySelector('[data-kit-counter]');
      const total = builder.querySelector('[data-kit-total]');
      const reviewText = builder.querySelector('[data-kit-review-text]');
      const reviewItems = builder.querySelector('[data-kit-review-items]');
      const addButton = builder.querySelector('[data-kit-add]');
      const error = builder.querySelector('[data-kit-error]');
      const shopifyRoot = (window.Shopify?.routes?.root || '/').replace(/\/?$/, '/');
      const money = value => {
        const cents = Math.round(Number(value) || 0);
        const format = window.Shopify?.money_format || '${{amount}}';
        if (typeof window.Shopify?.formatMoney === 'function') return window.Shopify.formatMoney(cents, format);
        const currency = window.Shopify?.currency?.active || 'AUD';
        return new Intl.NumberFormat(undefined, {style: 'currency', currency}).format(cents / 100);
      };
      const updateCardVariant = card => {
        const select = card.querySelector('[data-kit-variant]');
        const option = select?.selectedOptions?.[0];
        if (!option) return;
        card.dataset.variantId = option.value;
        card.dataset.price = option.dataset.price || card.dataset.price;
        card.dataset.productTitle = option.dataset.title || card.dataset.productTitle;
        card.dataset.variantAvailable = option.dataset.available !== 'false' ? 'true' : 'false';
        const price = card.querySelector('.ll-kit-card__price');
        if (price) price.textContent = money(card.dataset.price);
        const choose = card.querySelector('[data-kit-choose]');
        if (choose && !card.classList.contains('is-sold-out')) choose.disabled = card.dataset.variantAvailable === 'false';
      };
      const clearStep = stepIndex => {
        state.delete(stepIndex);
        const step = steps[stepIndex];
        step?.querySelectorAll('[data-kit-product]').forEach(card => {
          card.classList.remove('is-selected');
          card.querySelector('[data-kit-choose]')?.setAttribute('aria-pressed', 'false');
          const label = card.querySelector('[data-kit-choose-label]');
          if (label && !card.classList.contains('is-sold-out')) label.textContent = 'Add to kit';
        });
        step?.querySelector('[data-kit-step-state]')?.replaceChildren(document.createTextNode(step.dataset.kitRequired === 'true' ? 'Choose one' : 'Optional'));
      };
      const update = () => {
        let sum = 0;
        state.forEach(item => { sum += Number(item.price) || 0; });
        const count = state.size;
        if (counter) counter.textContent = requiredCount ? `${count} of ${requiredCount} packed` : 'No kit steps available';
        if (total) total.textContent = money(sum);
        const remaining = Math.max(requiredCount - count, 0);
        if (reviewText) reviewText.textContent = remaining === 0 && requiredCount > 0 ? 'Your little adventure is ready to pack.' : requiredCount === 0 ? 'This kit is waiting for available products.' : `Choose ${remaining} more ${remaining === 1 ? 'favourite' : 'favourites'} to complete the kit.`;
        if (addButton) addButton.disabled = requiredCount === 0 || count !== requiredCount;
        if (reviewItems) {
          reviewItems.replaceChildren();
          [...state.entries()].sort(([a], [b]) => a - b).forEach(([stepIndex, item]) => {
            const chip = document.createElement('span');
            chip.className = 'll-kit__review-chip';
            chip.textContent = item.title;
            const remove = document.createElement('button');
            remove.type = 'button'; remove.className = 'll-kit__review-remove'; remove.setAttribute('aria-label', `Remove ${item.title}`); remove.textContent = '×';
            remove.addEventListener('click', () => { clearStep(stepIndex); update(); });
            chip.append(remove); reviewItems.append(chip);
          });
        }
      };
      steps.forEach((step, stepIndex) => {
        step.querySelectorAll('[data-kit-product]').forEach(card => {
          card.dataset.variantAvailable = card.dataset.variantAvailable || (!card.classList.contains('is-sold-out') ? 'true' : 'false');
          card.querySelector('[data-kit-variant]')?.addEventListener('change', () => {
            updateCardVariant(card);
            if (state.get(stepIndex)?.card === card) {
              if (card.dataset.variantAvailable === 'false') clearStep(stepIndex);
              else state.set(stepIndex, {card, variantId: card.dataset.variantId, price: card.dataset.price, title: card.dataset.productTitle, stepTitle: step.dataset.kitStepTitle || `Step ${stepIndex + 1}`});
              update();
            }
          });
          card.querySelector('[data-kit-choose]')?.addEventListener('click', () => {
            if (card.classList.contains('is-sold-out') || card.dataset.variantAvailable === 'false') return;
            updateCardVariant(card);
            step.querySelectorAll('[data-kit-product]').forEach(other => {
              other.classList.remove('is-selected');
              other.querySelector('[data-kit-choose]')?.setAttribute('aria-pressed', 'false');
              const label = other.querySelector('[data-kit-choose-label]'); if (label && !other.classList.contains('is-sold-out')) label.textContent = 'Add to kit';
            });
            card.classList.add('is-selected');
            card.querySelector('[data-kit-choose]')?.setAttribute('aria-pressed', 'true');
            const label = card.querySelector('[data-kit-choose-label]'); if (label) label.textContent = 'In your kit ✓';
            state.set(stepIndex, {card, variantId: card.dataset.variantId, price: card.dataset.price, title: card.dataset.productTitle, stepTitle: step.dataset.kitStepTitle || `Step ${stepIndex + 1}`});
            step.querySelector('[data-kit-step-state]')?.replaceChildren(document.createTextNode('Packed ✓'));
            update();
          });
        });
      });
      addButton?.addEventListener('click', async () => {
        if (requiredCount === 0 || state.size !== requiredCount || addButton.dataset.kitAdding === 'true') return;
        const cartDrawer = document.querySelector('cart-drawer');
        addButton.disabled = true;
        addButton.dataset.kitAdding = 'true';
        addButton.setAttribute('aria-busy', 'true');
        const originalLabel = addButton.textContent;
        addButton.textContent = 'Adding your kit…';
        if (error) { error.hidden = true; error.textContent = ''; }
        if (cartDrawer?.setActiveElement) cartDrawer.setActiveElement(addButton);
        const items = [...state.entries()].sort(([a], [b]) => a - b).map(([stepIndex, item]) => ({
          id: Number(item.variantId),
          quantity: 1,
          properties: {
            _ll_kit_id: builder.id || 'summer-kit',
            _ll_kit_step: item.stepTitle || steps[stepIndex]?.dataset.kitStepTitle || `Step ${stepIndex + 1}`
          }
        }));
        const sections = (cartDrawer?.getSectionsToRender?.() || []).map(section => section.id);
        if (!sections.length) sections.push('cart-drawer', 'cart-icon-bubble');
        let added = false;
        let payload = {};
        try {
          const response = await fetch(`${shopifyRoot}cart/add.js`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json', Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest'},
            body: JSON.stringify({items, sections, sections_url: window.location.pathname})
          });
          payload = await response.json().catch(() => ({}));
          if (!response.ok || payload.status) throw new Error(payload.description || payload.message || 'We could not pack that kit just now.');
          added = true;
          publish('ll_summer_kit_add_to_cart', {items: items.map(item => ({variant_id: item.id, quantity: item.quantity})), item_count: items.length});
        } catch (err) {
          if (error) { error.hidden = false; error.textContent = err.message || 'We could not pack that kit just now. Please try again.'; }
        } finally {
          addButton.dataset.kitAdding = 'false';
          addButton.removeAttribute('aria-busy');
          addButton.textContent = added ? 'Added to bag ✓' : originalLabel;
          update();
          if (added) window.setTimeout(() => { if (addButton.isConnected) addButton.textContent = originalLabel; }, 1800);
        }
        if (!added) return;
        if (cartDrawer?.renderContents && payload.sections) {
          try {
            cartDrawer.classList.remove('is-empty');
            cartDrawer.renderContents(payload);
          } catch (renderError) {
            window.location.assign(window.routes?.cart_url || `${shopifyRoot}cart`);
          }
        } else {
          window.location.assign(window.routes?.cart_url || `${shopifyRoot}cart`);
        }
      });
      update();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => { init(); initAnnouncements(); initSearch(); initPopup(); initDrawer(); initKit(); initAnalytics(); }); else { init(); initAnnouncements(); initSearch(); initPopup(); initDrawer(); initKit(); initAnalytics(); }
})();
